<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Methods, Authorization");

$file = 'recipes.json'; // Lokasi file JSON
$method = $_SERVER['REQUEST_METHOD']; // Metode HTTP

switch ($method) {
    case 'GET':
        // Membaca data dari file JSON
        $data = file_get_contents($file);
        echo json_encode(json_decode($data), JSON_PRETTY_PRINT);
        break;

    case 'POST':
        // Menambahkan data baru
        $input = json_decode(file_get_contents('php://input'), true);
        $data = json_decode(file_get_contents($file), true);

        // Tambahkan input baru ke data JSON
        $data['recipes'][] = $input;
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT)); // Tulis dalam format JSON rapi
        echo json_encode(["message" => "Recipe added successfully"], JSON_PRETTY_PRINT);
        break;

    case 'PUT':
        // Memperbarui data
        parse_str(file_get_contents("php://input"), $_PUT);
        $data = json_decode(file_get_contents($file), true);

        foreach ($data['recipes'] as &$recipe) {
            if ($recipe['id'] == $_PUT['id']) {
                $recipe['name'] = $_PUT['name'];
                $recipe['description'] = $_PUT['description'];
                $recipe['image'] = $_PUT['image'];
            }
        }

        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT)); // Tulis dalam format JSON rapi
        echo json_encode(["message" => "Recipe updated successfully"], JSON_PRETTY_PRINT);
        break;

    case 'DELETE':
        // Menghapus data
        parse_str(file_get_contents("php://input"), $_DELETE);
        $data = json_decode(file_get_contents($file), true);

        // Hapus item berdasarkan ID
        $data['recipes'] = array_filter($data['recipes'], function ($recipe) use ($_DELETE) {
            return $recipe['id'] != $_DELETE['id'];
        });

        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT)); // Tulis dalam format JSON rapi
        echo json_encode(["message" => "Recipe deleted successfully"], JSON_PRETTY_PRINT);
        break;

    default:
        // Metode tidak diizinkan
        http_response_code(405);
        echo json_encode(["message" => "Method not allowed"], JSON_PRETTY_PRINT);
        break;
}
?>
