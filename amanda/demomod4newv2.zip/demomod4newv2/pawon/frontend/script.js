document.addEventListener("DOMContentLoaded", () => {
    const recipesContainer = document.getElementById("recipes-container");
    const form = document.getElementById("recipe-form");
  
    // Fungsi untuk mendapatkan data resep dari backend
    const fetchRecipes = () => {
      fetch("http://localhost:8000/backend/api/api.php?type=read")
        .then(response => response.json())
        .then(data => {
          recipesContainer.innerHTML = ""; // Bersihkan kontainer sebelum menambahkan elemen baru
          const ul = document.createElement("ul"); // Membuat elemen list
          ul.className = "recipe-list"; // Tambahkan kelas untuk styling
  
          data.recipes.forEach(recipe => {
            const li = document.createElement("li");
            li.className = "recipe-item"; // Tambahkan kelas untuk styling item
  
            li.innerHTML = `
              <h3>${recipe.name}</h3>
              <p>${recipe.description}</p>
              <img src="${recipe.image}" alt="${recipe.name}" class="recipe-image">
            `;
  
            ul.appendChild(li); // Tambahkan item ke dalam list
          });
  
          recipesContainer.appendChild(ul); // Tambahkan list ke dalam container
        })
        .catch(error => console.error("Error fetching recipes:", error));
    };
  
    // Fungsi untuk mengirim data baru ke backend
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = document.getElementById("recipe-name").value;
      const description = document.getElementById("recipe-description").value;
      const image = document.getElementById("recipe-image").value;
  
      fetch("http://localhost:8000/backend/api/api.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id: Date.now(), // ID unik menggunakan timestamp
          name,
          description,
          image
        })
      })
        .then(response => response.json())
        .then(data => {
          console.log(data.message);
          fetchRecipes(); // Refresh data resep
          form.reset(); // Reset form input
        })
        .catch(error => console.error("Error adding recipe:", error));
    });
  
    // Memuat data resep ketika halaman pertama kali dimuat
    fetchRecipes();
  });
  