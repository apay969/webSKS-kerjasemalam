<?php
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents('php://input'), true);
$villasFile = 'villas.json';

switch ($method) {
    case 'GET':
        echo file_get_contents($villasFile);
        break;
    case 'POST':
        $villas = json_decode(file_get_contents($villasFile), true);
        $villas[] = $data;
        file_put_contents($villasFile, json_encode($villas, JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Villa added successfully"]);
        break;
    case 'PUT':
        parse_str(file_get_contents("php://input"), $_PUT);
        $villas = json_decode(file_get_contents($villasFile), true);
        foreach ($villas as &$villa) {
            if ($villa['name'] === $_PUT['name']) {
                $villa = array_merge($villa, $_PUT);
            }
        }
        file_put_contents($villasFile, json_encode($villas, JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Villa updated successfully"]);
        break;
    case 'DELETE':
        parse_str(file_get_contents("php://input"), $_DELETE);
        $villas = json_decode(file_get_contents($villasFile), true);
        $villas = array_filter($villas, fn($villa) => $villa['name'] !== $_DELETE['name']);
        file_put_contents($villasFile, json_encode($villas, JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Villa deleted successfully"]);
        break;
}
