<?php
// router.php

header("Content-Type: application/json");

// Read the HTTP method and URI
$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['PATH_INFO'], '/'));

// Load the villas data file
$villasFile = 'villas.json';
$villas = json_decode(file_get_contents($villasFile), true);

// Helper function to send JSON response
function sendResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

// Define routing logic
if ($request[0] === 'villas') {
    switch ($method) {
        case 'GET':
            // GET /villas or GET /villas/{id}
            if (isset($request[1])) {
                // Get villa by ID
                $id = (int)$request[1];
                if (isset($villas[$id])) {
                    sendResponse($villas[$id]);
                } else {
                    sendResponse(["error" => "Villa not found"], 404);
                }
            } else {
                // Get all villas
                sendResponse($villas);
            }
            break;

        case 'POST':
            // POST /villas
            $input = json_decode(file_get_contents('php://input'), true);
            if ($input) {
                $villas[] = $input;
                file_put_contents($villasFile, json_encode($villas, JSON_PRETTY_PRINT));
                sendResponse(["message" => "Villa added successfully"], 201);
            } else {
                sendResponse(["error" => "Invalid input"], 400);
            }
            break;

        case 'PUT':
            // PUT /villas/{id}
            if (isset($request[1])) {
                $id = (int)$request[1];
                $input = json_decode(file_get_contents('php://input'), true);
                if (isset($villas[$id]) && $input) {
                    $villas[$id] = array_merge($villas[$id], $input);
                    file_put_contents($villasFile, json_encode($villas, JSON_PRETTY_PRINT));
                    sendResponse(["message" => "Villa updated successfully"]);
                } else {
                    sendResponse(["error" => "Villa not found or invalid input"], 404);
                }
            } else {
                sendResponse(["error" => "Villa ID is required"], 400);
            }
            break;

        case 'DELETE':
            // DELETE /villas/{id}
            if (isset($request[1])) {
                $id = (int)$request[1];
                if (isset($villas[$id])) {
                    unset($villas[$id]);
                    file_put_contents($villasFile, json_encode(array_values($villas), JSON_PRETTY_PRINT));
                    sendResponse(["message" => "Villa deleted successfully"]);
                } else {
                    sendResponse(["error" => "Villa not found"], 404);
                }
            } else {
                sendResponse(["error" => "Villa ID is required"], 400);
            }
            break;

        default:
            sendResponse(["error" => "Method not allowed"], 405);
    }
} else {
    sendResponse(["error" => "Endpoint not found"], 404);
}
