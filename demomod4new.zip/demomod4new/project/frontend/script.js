document.addEventListener('DOMContentLoaded', () => {
    const villaList = document.querySelector('.villa-list');
    const villaForm = document.getElementById('villaForm');

    async function loadVillas() {
        const response = await fetch('../backend/villas.json');
        const villas = await response.json();
        villas.forEach(villa => {
            const div = document.createElement('div');
            div.className = 'villa-item';
            div.innerHTML = `
                <h3>${villa.name}</h3>
                <p>Location: ${villa.location}</p>
                <p>Price: $${villa.price}/night</p>
                <p>${villa.description}</p>
            `;
            villaList.appendChild(div);
        });
    }

    villaForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newVilla = {
            name: document.getElementById('name').value,
            location: document.getElementById('location').value,
            price: parseInt(document.getElementById('price').value, 10),
            description: document.getElementById('description').value
        };

        await fetch('../backend/index.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newVilla)
        });

        alert('Villa added successfully!');
        location.reload();
    });

    loadVillas();
});
